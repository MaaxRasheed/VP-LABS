﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10_Do_it_Yourself
{
    internal class Employee
    {
        public int EmpId {  get; set; }
        public string?Name { get; set; }
        public string?FatherName { get; set; }
        public string?CNIC { get; set; }
        public string?Designation { get; set; }
        public int Salary { get; set; }
        public string?Department { get; set; }
        public DateTime HireDate { get; set; }
    }
}
