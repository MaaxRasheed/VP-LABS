using System.Data.SqlTypes;
using System.Numerics;
using Lab_10_Do_it_Yourself.Migrations;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Windows.Forms;
using System.Xml.Linq;


namespace Lab_10_Do_it_Yourself
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox4.MaxLength = 13;
        }
        private void LoadData()
        {
            EmployeeContext empCon = new EmployeeContext();

            dataGridView1.DataSource = empCon.employee.ToList();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text))
                {
                    throw new Exception("Names cannot be empty.");
                }
                Employee employee = new Employee()
                {
                    EmpId = Convert.ToInt32(textBox1.Text),
                    Name = textBox2.Text,
                    FatherName = textBox3.Text,
                    CNIC = textBox4.Text,
                    Designation = textBox5.Text,
                    Salary = Convert.ToInt32(textBox6.Text),
                    Department = comboBox1.Text,
                    HireDate = dateTimePicker1.Value
                };
                EmployeeContext empCon = new EmployeeContext();
                empCon.Add(employee);
                empCon.SaveChanges();
                LoadData();
                MessageBox.Show("Added Successfully");

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Sql error:{ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) { e.Handled = true; }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            EmployeeContext empCon = new EmployeeContext();
            dataGridView1.DataSource = empCon.employee.ToList();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    throw new Exception("EmpID cannot be empty.");
                }
                Employee employee = new Employee()
                {
                    EmpId = Convert.ToInt32(textBox1.Text),

                };

                EmployeeContext empCon = new EmployeeContext();
                empCon.Remove(employee);
                empCon.SaveChanges();
                LoadData();
                MessageBox.Show("Removed Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {

                if (string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text))
                {
                    throw new Exception("Names cannot be empty.");
                }
                Employee employee = new Employee()
                {
                    EmpId = Convert.ToInt32(textBox1.Text),
                    Name = textBox2.Text,
                    FatherName = textBox3.Text,
                    CNIC = textBox4.Text,
                    Designation = textBox5.Text,
                    Salary = Convert.ToInt32(textBox6.Text),
                    Department = comboBox1.Text,
                    HireDate = dateTimePicker1.Value
                };
                EmployeeContext empCon = new EmployeeContext();
                empCon.Update(employee);
                empCon.SaveChanges();
                LoadData();
                MessageBox.Show("Updated Successfully");

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Sql error:{ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["EmpId"].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["Name"].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["FatherName"].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells["CNIC"].Value.ToString();
                textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells["Designation"].Value.ToString();
                textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells["Salary"].Value.ToString();
                comboBox1.SelectedItem = dataGridView1.Rows[e.RowIndex].Cells["Department"].Value.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells["HireDate"].Value);
            }
        }
    }
}
