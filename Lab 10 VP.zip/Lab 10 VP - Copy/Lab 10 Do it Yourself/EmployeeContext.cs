﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10_Do_it_Yourself
{
    internal class EmployeeContext:DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(localdb)\\mylocaldb; Database=EmployeeDB ; Trusted_connection=True");
        }
        public DbSet<Employee> employee { get; set; }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>().Property(e => e.EmpId).ValueGeneratedNever();
            modelBuilder.Entity<Employee>().HasKey(e => e.EmpId);
        }
    }
}
